package com.basic.myspringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.WebApplicationType;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
//@SpringBootConfiguration + @EnableAutoConfiguration + @ComponentScan
public class MySpringBoot3AppApplication {

	public static void main(String[] args) {

		//SpringApplication.run(MySpringBoot3AppApplication.class, args);
		SpringApplication application = new SpringApplication(MySpringBoot3AppApplication.class);
		application.setWebApplicationType(WebApplicationType.SERVLET); //웹어플리케이션 타입 지정
		application.run(args);
	}

	@Bean
	public String hello() {
		return "Hello SpringBoot!!";
	}


}
