package com.basic.myspringboot.dto;

public enum AccountType {
    SAVING, CHECKING
}