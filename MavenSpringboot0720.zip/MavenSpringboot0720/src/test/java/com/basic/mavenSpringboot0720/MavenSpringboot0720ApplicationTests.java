package com.basic.mavenSpringboot0720;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MavenSpringboot0720ApplicationTests {

	@Test
	void contextLoads() {
	}

}
