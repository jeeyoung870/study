package com.basic.mavenSpringboot0720;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MavenSpringboot0720Application {

	public static void main(String[] args) {
		SpringApplication.run(MavenSpringboot0720Application.class, args);
	}

}
